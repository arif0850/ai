/**
 * quiz.js
 * Dynamic German plural quiz.
 *
 * The noun database (german/data/nouns-a1.json) is the single source of
 * truth. This file never hardcodes a question or an answer — every
 * question is generated at run time from whatever is in the database.
 * Adding, editing, or removing a noun in the JSON file changes the quiz
 * automatically, with no code changes required.
 */

(function () {
  "use strict";

  const DATA_URL = "data/nouns-a1.json";

  /** @type {Array<Object>} the full noun database, once loaded */
  let nounDatabase = [];

  /** Current quiz run state */
  const state = {
    questions: [],   // ordered list of question objects for this run
    index: 0,        // current question index
    correct: 0,      // correct answers so far
    wrong: 0,         // wrong answers so far
    answered: false, // has the current question been answered?
  };

  // ---- DOM references -----------------------------------------------
  const setupScreen = document.getElementById("setup-screen");
  const quizScreen = document.getElementById("quiz-screen");
  const resultScreen = document.getElementById("result-screen");

  const lengthOptions = document.getElementById("length-options");
  const startBtn = document.getElementById("start-btn");
  const setupStatus = document.getElementById("setup-status");

  const progressLabel = document.getElementById("progress-label");
  const scoreLabel = document.getElementById("score-label");
  const progressFill = document.getElementById("progress-fill");
  const questionWord = document.getElementById("question-word");
  const answersList = document.getElementById("answers-list");
  const nextBtn = document.getElementById("next-btn");
  const liveFeedback = document.getElementById("live-feedback");

  const resultPercentage = document.getElementById("result-percentage");
  const resultMessage = document.getElementById("result-message");
  const statTotal = document.getElementById("stat-total");
  const statCorrect = document.getElementById("stat-correct");
  const statWrong = document.getElementById("stat-wrong");
  const retryBtn = document.getElementById("retry-btn");

  let selectedLength = null;

  // ---- Data loading ----------------------------------------------------

  function validateNoun(entry) {
    // Guard against malformed entries so one bad row can't break the quiz.
    return (
      entry &&
      typeof entry.singular === "string" && entry.singular.trim() !== "" &&
      typeof entry.plural === "string" && entry.plural.trim() !== ""
    );
  }

  async function loadNouns() {
    try {
      const response = await fetch(DATA_URL);
      if (!response.ok) throw new Error("Network response was not ok");
      const raw = await response.json();
      nounDatabase = Array.isArray(raw) ? raw.filter(validateNoun) : [];

      if (nounDatabase.length < 4) {
        setupStatus.textContent =
          "Not enough valid words in the database to build a quiz.";
        return;
      }

      setupStatus.textContent = `${nounDatabase.length} words loaded.`;
    } catch (err) {
      setupStatus.textContent =
        "Could not load the word database. If you're opening this file " +
        "directly from disk, run it through a local server instead " +
        "(this works automatically once hosted, e.g. on GitHub Pages).";
      console.error(err);
    }
  }

  // ---- Helpers -----------------------------------------------------

  function shuffle(array) {
    const copy = array.slice();
    for (let i = copy.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [copy[i], copy[j]] = [copy[j], copy[i]];
    }
    return copy;
  }

  function pickRandomQuestions(count) {
    const pool = shuffle(nounDatabase);
    const size = count === "all" ? pool.length : Math.min(count, pool.length);
    return pool.slice(0, size);
  }

  /**
   * Build 4 unique answer options (1 correct + 3 distractors) for a noun.
   * Distractors are drawn from other nouns' plural forms in the database,
   * which keeps them plausible (real German plural forms) without ever
   * hardcoding a wrong answer.
   */
  function buildOptions(correctNoun) {
    const options = new Set([correctNoun.plural]);

    const candidates = shuffle(
      nounDatabase.filter((n) => n.plural !== correctNoun.plural)
    );

    let i = 0;
    while (options.size < 4 && i < candidates.length) {
      options.add(candidates[i].plural);
      i++;
    }

    // Extremely small databases could still fall short of 4 unique
    // options; pad with a controlled distractor rather than fail.
    let fallbackSuffix = 1;
    while (options.size < 4) {
      options.add(`${correctNoun.plural} (${fallbackSuffix++})`);
    }

    return shuffle(Array.from(options));
  }

  // ---- Setup screen ----------------------------------------------------

  lengthOptions.addEventListener("click", (e) => {
    const btn = e.target.closest(".option-pill");
    if (!btn) return;

    lengthOptions
      .querySelectorAll(".option-pill")
      .forEach((el) => el.setAttribute("aria-pressed", "false"));
    btn.setAttribute("aria-pressed", "true");

    const raw = btn.dataset.length;
    selectedLength = raw === "all" ? "all" : Number(raw);
    startBtn.disabled = false;
  });

  startBtn.addEventListener("click", () => {
    if (selectedLength === null || nounDatabase.length < 4) return;
    startQuiz(selectedLength);
  });

  retryBtn.addEventListener("click", () => {
    resultScreen.hidden = true;
    setupScreen.hidden = false;
  });

  // ---- Quiz flow -----------------------------------------------------

  function startQuiz(length) {
    state.questions = pickRandomQuestions(length).map((noun) => ({
      noun,
      options: buildOptions(noun),
    }));
    state.index = 0;
    state.correct = 0;
    state.wrong = 0;
    state.answered = false;

    setupScreen.hidden = true;
    resultScreen.hidden = true;
    quizScreen.hidden = false;

    renderQuestion();
  }

  function renderQuestion() {
    const total = state.questions.length;
    const current = state.questions[state.index];

    progressLabel.textContent = `Question ${state.index + 1} of ${total}`;
    scoreLabel.textContent = `Score: ${state.correct}`;
    progressFill.style.width = `${(state.index / total) * 100}%`;

    questionWord.textContent = current.noun.singular;

    answersList.innerHTML = "";
    const letters = ["A", "B", "C", "D"];

    current.options.forEach((optionText, i) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "answer-btn";
      btn.dataset.value = optionText;
      btn.innerHTML =
        `<span class="letter">${letters[i]}</span><span>${escapeHtml(optionText)}</span>`;
      btn.addEventListener("click", () => handleAnswer(btn, optionText, current));
      answersList.appendChild(btn);
    });

    state.answered = false;
    nextBtn.disabled = true;
    nextBtn.textContent =
      state.index === total - 1 ? "See results" : "Next question";
  }

  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }

  function handleAnswer(button, chosenText, question) {
    if (state.answered) return; // one answer per question
    state.answered = true;

    const isCorrect = chosenText === question.noun.plural;
    if (isCorrect) {
      state.correct++;
      button.classList.add("correct");
      liveFeedback.textContent = "Correct.";
    } else {
      state.wrong++;
      button.classList.add("incorrect");
      liveFeedback.textContent = `Incorrect. The correct answer is ${question.noun.plural}.`;
    }

    // Lock all options and reveal the correct one if the user got it wrong.
    Array.from(answersList.children).forEach((btn) => {
      btn.disabled = true;
      if (btn.dataset.value === question.noun.plural) {
        btn.classList.add("correct");
      }
    });

    scoreLabel.textContent = `Score: ${state.correct}`;
    nextBtn.disabled = false;
  }

  nextBtn.addEventListener("click", () => {
    if (state.index < state.questions.length - 1) {
      state.index++;
      renderQuestion();
    } else {
      showResults();
    }
  });

  function showResults() {
    const total = state.questions.length;
    const percentage = Math.round((state.correct / total) * 100);

    progressFill.style.width = "100%";
    quizScreen.hidden = true;
    resultScreen.hidden = false;

    resultPercentage.textContent = `${percentage}%`;
    statTotal.textContent = String(total);
    statCorrect.textContent = String(state.correct);
    statWrong.textContent = String(state.wrong);

    let message;
    if (percentage === 100) message = "Perfect score!";
    else if (percentage >= 80) message = "Excellent!";
    else if (percentage >= 60) message = "Good work — keep practicing.";
    else if (percentage >= 40) message = "Getting there — review and try again.";
    else message = "Keep at it — repetition is how this sticks.";

    resultMessage.textContent = message;
  }

  // ---- Init -----------------------------------------------------
  loadNouns();
})();
