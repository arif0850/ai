# hiarif.com

Personal portfolio for Arif, with an integrated German learning platform
("Learn German with Arif"). Static site, built for GitHub Pages — no
backend, no build step.

## Structure

```
/
├── index.html                 Portfolio homepage
├── german/
│   ├── index.html             German dashboard ("Learn German with Arif")
│   ├── plural-quiz.html       German Plural Quiz (dynamic, data-driven)
│   ├── vocabulary.html        Coming soon
│   ├── grammar.html           Coming soon
│   ├── flashcards.html        Coming soon
│   ├── games.html             Coming soon
│   └── data/
│       └── nouns-a1.json      Single source of truth: 215 A1 nouns
├── assets/
│   ├── css/
│   │   ├── style.css          Shared tokens + portfolio styles
│   │   └── german.css         German-section-specific styles
│   ├── js/
│   │   ├── main.js            Shared nav behavior
│   │   └── quiz.js            Quiz engine (reads nouns-a1.json)
│   └── images/
│       └── profile-placeholder.svg
└── README.md
```

## Editing the portfolio

Open `index.html` and look for the `[Editable ...]` placeholders and
`<!-- EDITABLE -->` comments — swap in your real bio, skills, experience,
education, projects, and contact details directly in the HTML. To add a
new skill, timeline entry, or project card, copy an existing `<li>` or
`.project-card` block and edit the text.

To replace the avatar placeholder, swap the `src` on the `<img>` inside
`.avatar-frame` in `index.html` for your own photo — the layout doesn't
depend on the image's presence or shape.

## Adding vocabulary

Everything the quiz knows comes from `german/data/nouns-a1.json`. To add a
word, append a new object to the array:

```json
{
  "id": 216,
  "singular": "die Uhr",
  "plural": "die Uhren",
  "singularNoun": "Uhr",
  "pluralNoun": "Uhren",
  "article": "die",
  "category": "Objects",
  "english": "clock",
  "bengali": "ঘড়ি",
  "level": "A1"
}
```

No JavaScript changes are needed — `quiz.js` reads the file at run time,
so new nouns are automatically eligible to appear as questions and as
distractors for other questions. The same is true if you edit an existing
plural form: the quiz picks up the change immediately.

`quiz.js` validates each entry has a non-empty `singular` and `plural`
before using it, so one malformed row won't break the whole quiz — it's
just skipped.

## Adding a new German module

The dashboard (`german/index.html`) is a grid of `.module-card` elements.
To turn a "Coming soon" card into a working module:

1. Build the new page (e.g. `german/vocabulary.html`), following the same
   `<head>`/nav/footer structure as the other German pages.
2. In `german/index.html`, change that card's class from `is-soon` to
   `is-available`, update its status text, and add a link/button to the
   new page.

No other files need to change.

## Adding a new quiz mode

`plural-quiz.html` and `quiz.js` currently implement one mode: singular →
plural. To add another mode later (e.g. article quiz, English → German),
the recommended approach is:

1. Duplicate `plural-quiz.html` and `quiz.js` as a new pair (e.g.
   `article-quiz.html` / `article-quiz.js`), or parameterize `quiz.js`
   with a "mode" setting if you'd rather keep one engine.
2. Both approaches can keep reading the same `nouns-a1.json` — the data
   format already has everything needed (article, English, Bengali) for
   modes beyond plurals.
3. Add a new card to the dashboard grid pointing at the new page.

## Running locally

Because the quiz loads `nouns-a1.json` via `fetch()`, opening `index.html`
directly from disk (a `file://` URL) will block that request in most
browsers. Serve the folder locally instead, for example:

```
python3 -m http.server 8000
```

then visit `http://localhost:8000/`. This restriction does not apply once
the site is hosted on GitHub Pages — `fetch()` works normally over
`https://`.

## Deploying to GitHub Pages

1. Push this folder's contents to the root of your repository (or to a
   `docs/` folder, if you configure Pages that way).
2. In the repository's Pages settings, set the custom domain to
   `hiarif.com` and add the corresponding DNS records with your domain
   provider.
3. All links in this project are relative, so it will also work correctly
   if served from a subpath instead of the domain root.

## A note on the Bengali translations

The `bengali` field in `nouns-a1.json` is provided as a learning aid.
Translations for ~200 words were generated in one pass — it's worth
spot-checking the entries most relevant to you before relying on them.
